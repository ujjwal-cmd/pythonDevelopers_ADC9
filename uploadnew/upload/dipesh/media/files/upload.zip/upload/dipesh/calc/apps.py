from django.apps import AppConfig


class CalcConfig(AppConfig):
    name = 'calc'
